package exam5.ex1;

public interface Enemy {
	void turnRight();
	void turnLeft();
	void driveForward();
	void driveBackward();
	void fireWeapon();

}
