package exam5.ex1;

public class EnemyAdapter implements Enemy {
	
	Enemy enemy;

	public EnemyAdapter(Enemy enemy) {
		super();
		this.enemy = enemy;
	}

	@Override
	public void turnRight() {
		enemy.turnRight();
		
	}

	@Override
	public void turnLeft() {
		enemy.turnLeft();
		
	}

	@Override
	public void driveForward() {
		enemy.driveForward();
		
	}

	@Override
	public void driveBackward() {
		enemy.driveBackward();
		
	}

	@Override
	public void fireWeapon() {
		enemy.fireWeapon();
		
	}
	

}
