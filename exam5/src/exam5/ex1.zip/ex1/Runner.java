package exam5.ex1;

public class Runner {

	public static void main(String[] args) {
		EnemyTank enemyTank = new EnemyTank("Tank-1", 123);
		BadHelicopter badHelicopter = new BadHelicopter("Helicopter",111);
		EnemyAdapter adapter = new EnemyAdapter(enemyTank);
		
		enemyTank.driveForward();
		badHelicopter.driveBackward();
		adapter.driveForward();

	}

}
